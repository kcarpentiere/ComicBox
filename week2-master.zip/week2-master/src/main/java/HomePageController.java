import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import java.util.List;

    @Controller
    public class HomePageController {

        public String index(Model model) {
            // Stats
            model.addAttribute("totalIssues", 6);
            model.addAttribute("totalCollection", 4);
            model.addAttribute("totalWishlist", 2);
            model.addAttribute("avgRating", 4.7);

            // Comic issues
            List<ComicIssue> issues = List.of(
                    new ComicIssue("The Amazing Spider-Man", "#1", "1963", "VF", "OWNED",
                            "Stan Lee", "Steve Ditko", 4.5, "/images/asm-1.jpg"),
                    new ComicIssue("Uncanny X-Men", "#1", "1963", "FN", "OWNED",
                            "Stan Lee", "Jack Kirby", 4.2, "/images/xmen-1.jpg"),
                    new ComicIssue("The Avengers", "#4", "1964", "GD", "OWNED",
                            "Stan Lee", "Jack Kirby", 4.8, "/images/avengers-4.jpg"),
                    new ComicIssue("Iron Man: Extremis", "#1", "2005", "NM", "OWNED",
                            "Warren Ellis", "Adi Granov", 4.6, "/images/ironman-extremis-1.jpg"),
                    new ComicIssue("Thor: God of Thunder", "#1", "2012", "VF", "WANT",
                            "Jason Aaron", "Esad Ribić", 4.4, "/images/thor-god-1.jpg"),
                    new ComicIssue("Black Panther", "#1", "2016", "NM", "WANT",
                            "Ta-Nehisi Coates", "Brian Stelfreeze", 4.7, "/images/blackpanther-1.jpg")
            );
            model.addAttribute("issues", issues);

            return "index";
        }

        // Record for comic data
        public record ComicIssue(
                String title,
                String issueNumber,
                String year,
                String condition,
                String status,   // "OWNED" or "WANT"
                String writer,
                String artist,
                double rating,
                String coverImage
        ) {}
    }



